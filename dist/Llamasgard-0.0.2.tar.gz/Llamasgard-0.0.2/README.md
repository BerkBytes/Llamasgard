# Llamasgard

A package to interact with the CodeLlama API.

## Installation

Run the following:

```bash
pip install ./dist/Llamasgard-0.1.tar.gz
```